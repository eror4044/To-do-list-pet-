const Router = require('express')
const authMiddleware = require('../middleware/authMiddleware')
const router = new Router()
const taskController = require('../controllers/taskController')
router.post('/createTask',authMiddleware, taskController.createTask)
router.get('/getTasks',authMiddleware, taskController.getTasks)
router.get('/deleteTask',authMiddleware, taskController.getTasks)

module.exports = router